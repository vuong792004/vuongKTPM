import { useEffect, useState } from "react";
import Banner from "../components/home/banner";
import Product from "../components/home/product";


const HomePage = () => {



    return (
        <>
            <Banner />
            <Product />
        </>
    );


}

export default HomePage;    